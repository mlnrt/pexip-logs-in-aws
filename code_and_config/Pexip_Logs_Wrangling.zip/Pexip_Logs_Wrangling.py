'''
/* This file is under the MIT License
 * 
 * Copyright (c) 2019 mlnrt
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
------------------------------------------------------------------------------

This Lambda function is set up as a subscription to a Cloudwatch Logs group. 
As new logs are written to the log group, they're sent to this Lambda, which unzips them,
pulls out the log messages, and invokes another Lambda function "Pexip_Logs_Export" 
which will export the logs to a different CloudWatch Logs log-group and to S3.

The code of this function is based on the code written by 
  @ V.Megler 
  @ Copyright 2017 Amazon.com 
  @ August 2017  
provided in this blog post: https://aws.amazon.com/blogs/mt/how-to-export-ec2-instance-execution-logs-to-an-s3-bucket-using-cloudwatch-logs-lambda-and-cloudformation/

@author Matthieu Lienart
@date March 2019
'''
import boto3
import logging
import json
import gzip
import os
import base64
import re
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

audit_log_details_is_int = ['syscall','exit','argc','items','ppid','pid','uid','auid','gid','euid','suid','fsuid','egid','sgid','fsgid','ses','item','inode','mode','oauid','opid','ouid','ogid','oses','ino','permissive','entries']
support_log_details_is_int = ['Src-port','Dst-port','Local-candidate-port','Remote-candidate-port','Licenses','Stream-id','expires', 'Pid', 'Remote-Port', 'Port', 'Transaction_id','Floor_request_id', 'Local-port', 'Remote-port']
support_log_details_is_boolean = ['Registered'] 


'''
------------------------------------------------------------------------------
 * Unfolds the SDP as a list of JSON of as one JSON with the key being the 
 * line number
------------------------------------------------------------------------------'''
def format_sdp_as_list_of_strings(sdp_as_string, debugging_log_level):
    debug_header = 'format_sdp_as :: '
    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
        logger.info(debug_header + 'Parsing the SDP and formating it as a list of \"key=value\" strings')
    if (debugging_log_level == 'Debug'):
        logger.info(debug_header + sdp_as_string)

    json_SDP = []

    # Unfolds the SDP content as a list of JSON
    SDP_iterator = re.finditer(r'(\w*=[^\^]*)(?:\^M|$)',sdp_as_string)
    # Old parser : SDP_iterator = re.finditer(r'(\w*=[^\^]*(?:\^(?!\^)[^M])*)(\^M)',sdp_as_string)
    if (SDP_iterator):
        # The SDP can can be parsed as a key=value content.
        # These key=value will be all stored as one string item in the sdp list of the JSON logs 
        # {sdp: ['key1=value1', 'key2=value2'...]}
        for SDP_match in SDP_iterator:
            json_SDP.append(SDP_match.group(1))
    else:
        # The SDP could not be parsed so it will be stored as one long string
        json_SDP = sdp_string
    return json_SDP


'''
---------------------------------------------------------------------------------
 * Function which formats the key-value pair of the log data
---------------------------------------------------------------------------------'''
def format_json_key_value_pair(log_type, log_to_update, key, value, remove_double_quote=False):  
    debug_header = 'format_json_key_value_pair :: '
    #logger.info(debug_header + 'key='+str(key))
    #logger.info(debug_header + 'value='+str(value))
    if (log_type == 'audit'):
        # If the value is not None
        if value is not None:
            # Check if the key is in the list of audit logs key-value pairs that are integers or not
            if (key in audit_log_details_is_int):
                if (value == 'n/a'):
                    json_value = None
                else:
                    json_value = int(value)
            elif (remove_double_quote):
                json_value = str.replace(value,'\"','')
            else:
                json_value = value
        else:
            # Keep the None value
            json_value = value
        # Edit the key-value pair of the JSON dictionary
        # For AWS Glue '-' have to be replaced by '_' as '-' are not allowed in columns names
        log_to_update[str.replace(key,'-','_')] = json_value
    elif (log_type == 'support'):
        # If the value is not None
        if value is not None:
            # Check if the key is in the list of support logs key-value pairs that are integers or not
            if (key in support_log_details_is_int):
                # For an unkown reason there are fields like "Remote-Port" which are logged with a boolean value like "false"
                # So for fields which should be integer but have boolean value, it will be converted to None
                if (value == 'False') or (value == 'True') or (value == 'None'):
                    json_value =  None
                else:
                    json_value = int(value)
            elif (key in support_log_details_is_boolean):
                json_value = value == 'True'
            # Transform time stamps from "2019-05-11T08:29:33,751132" to "2019-05-11 08:29:33,751132" for AWS Athena
            elif (key == 'Received-time'):
                json_value = str.replace(str.replace(value,'T',' '),',','.')
            elif (remove_double_quote):
                json_value = str.replace(value,'\"','')
            else:
                json_value = value
        else:
            # Keep the None value
            json_value = value
        # Edit the key-value pair of the JSON dictionary
        # For AWS Glue '-' have to be replaced by '_' as '-' are not allowed in columns names
        log_to_update[str.replace(key,'-','_')] = json_value
    else:
        logger.info(debug_header + 'ERROR: ' + 'The type of log of the key-value pair could not be identified. The value was formated as string by default')
        # If can't identify what type of log it is, we can't check if it should be an intger or not,
        # so keep the value as string
        if (remove_double_quote):
            string_value = str.replace(value,'\"','')
        else:
            string_value = value
            # Edit the key-value pair of the JSON dictionary
            # For AWS Glue '-' have to be replaced by '_' as '-' are not allowed in columns names
            log_to_update[str.replace(key,'-','_')] = json_value
    #return log_to_update


'''
------------------------------------------------------------------------------
 * Parse the "Detail" field of the log's message 
 * The Detail field can have several formats
 * Detail="Stream 0 (audio)"
 * Detail="{u'sdp': u'v=0^Mo=xxxx^M ....', u'call_type': u'WEBRTC'}"
 * Detail="{'status': 'success', 'result': {'allow_1080p': False, ...}...}
 * Detail="request:^M  openLogicalChannel:^M    forwardLogicalChannelNumber: 1^M..."
 *
 * The output will be formated to either a JSON content or a list fo string(s)
 * This is made in order to limit the number of different types of structures
 * the Detail field will have
------------------------------------------------------------------------------'''
def parse_support_logs_Detail_field(support_log_name, log_message_Detail_field, debugging_log_level):
    debug_header = 'parse_support_logs_Detail_field :: '
    # Test if the Detail field is a JSON dictionary, a list of lines splitted by ^M or something else
    Detail_field_match = re.match(r'^{(.*)}$|^((?:[^\^]*(?:\^M))+[^\^]*)$|^(.*)$',log_message_Detail_field)
    # ^{(.*)}$|^(\w*[^\^]*(?:\^(?!\^)[^M])*)(?:\^M\s*|$)|^(.*)$

    if (Detail_field_match):
        if (Detail_field_match.group(1)):
            # The Detail field looks like JSON data
            # Cleanup the JSON string first
            reformated_Detail_field = Detail_field_match.group(0)
            replacement = {
                "{u'": "{\"",
                "': u'": "\": \"",
                ", u'": ", \"",
                "'": "\"",
                "False": "false",
                "True": "true",
                "None": "null"
            }
            for k,v in replacement.items():
                reformated_Detail_field = str.replace(reformated_Detail_field,k,v)

            # Try to parse the Detail field
            try:
                Detail_field_as_dict = json.loads(reformated_Detail_field)
                # Check if there is a SDP inside the Detail field
                if ('sdp' in Detail_field_as_dict):
                    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                        logger.info(debug_header + 'A SDP was found')
                    # Extract the SDP string as a list of strings "sdp_key=sdp_value"
                    # I.e make a list of all the lines in the SDP
                    Detail_field_as_dict['sdp'] = format_sdp_as_list_of_strings(Detail_field_as_dict['sdp'], debugging_log_level)
                # The "result" field inside the Detail field can take too many forms which is problematic 
                # as we want to avoid creating multiple data format/tables in the log analysis tool
                # So if the result key's value is not a dictionary: reformat it as a dictionary with the result content
                # equal to the value of an artificial key named "result_message"
                # If it is a list: transform it into a string
                elif ('result' in Detail_field_as_dict) and (Detail_field_as_dict['result'] is not None) and (isinstance(Detail_field_as_dict['result'],list)):
                    Detail_field_as_dict['result'] = {"result_message": ''.join(str(e)+'\n' for e in Detail_field_as_dict['result'])}
                # If it is something else than a dictionary: create an artificial field "result_message" inside a sub dictionary
                elif ('result' in Detail_field_as_dict) and (Detail_field_as_dict['result'] is not None) and (not isinstance(Detail_field_as_dict['result'],dict)):
                    Detail_field_as_dict['result'] = {"result_message": str(Detail_field_as_dict['result'])}
                # If it is a dictionary, we're good but let's check if there is an SDP inside it, and if yes, parse it
                elif ('result' in Detail_field_as_dict) and (Detail_field_as_dict['result'] is not None) and ('sdp' in Detail_field_as_dict['result']):
                    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                        logger.info(debug_header + 'A SDP was found')
                    # Extract the SDP string as a list of strings "sdp_key=sdp_value"
                    # I.e make a list of all the lines in the SDP
                    Detail_field_as_dict['result']['sdp'] = format_sdp_as_list_of_strings(Detail_field_as_dict['result']['sdp'], debugging_log_level)
                Detail_field_json = Detail_field_as_dict
            except Exception as e:
                if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                    logger.info(debug_header + 'The Detail field of the log looks like JSON content but the JSON parser failed. The Detail field will be returned as a string')
                if (debugging_log_level == 'Debug'):
                    logger.info(debug_header + 'formated content is: ' + str(reformated_Detail_field))
                    logger.info(debug_header + 'ERROR: ' + str(e))
                Detail_field_json = [Detail_field_match.group(0)]
        elif (Detail_field_match.group(2)):
            # The Detail field looks like a text of multiple lines
            # This is either h323 message details in the format of
            #   "request:^M  openLogicalChannel:^M    forwardLogicalChannelNumber: 1^M"
            # Or a SIP message in the format
            #   "SIP/2.0 200 OK^MVia: SIP/2.0/TLS 10.1.1.1:5061;branch=a3zg9hG54kbKQ5ZC2...."
            #
            # Only SIP message will be parsed with the header fields From:, To:... transformed as a JSON key-value pairs 
            # and the DSP as a key "SDP" with the value being a list of all lines
            # For any other type of logs, even if the Detail field has just one string, we will transform it to a list of strings
            # On purpose we keep at each line the space indentation to make the content hierarchy human readable if displayed
            Detail_field_lines_iterator = re.finditer(r'(?:\^M)*((?:\w| )[^\^]*)(?:(\^M)+|$)',log_message_Detail_field)
            if (Detail_field_lines_iterator):
                if support_log_name == 'support.sip':
                    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                        logger.info(debug_header + 'Wrangle the content of the SIP message into JSON. The SDP will be a list of strings attached to the key "SDP".')
                    Detail_field_json = {"Header": next(Detail_field_lines_iterator).group(1)}
                    # For all other lines, store the header as key:value and the SDP as a list of strings
                    for Detail_field_line in Detail_field_lines_iterator:
                        SIP_Message_match = re.match(r'([^=]*?):\s?(.*)|(.*=.*)',Detail_field_line.group(1))
                        if SIP_Message_match:
                            if SIP_Message_match.group(1):
                                # This is a SIP Header field
                                format_json_key_value_pair('support', Detail_field_json, SIP_Message_match.group(1), SIP_Message_match.group(2))
                            else:
                                # This is the SDP. Let's treat it as a list of strings
                                if 'SDP' not in Detail_field_json:
                                    Detail_field_json['SDP'] = []
                                Detail_field_json['SDP'].append(SIP_Message_match.group(3))
                else:
                    # Return the content as a list of line
                    Detail_field_json = []
                    for Detail_field_line in Detail_field_lines_iterator:
                        Detail_field_json.append(Detail_field_line.group(1))
            else:
                # If the parser failed, return the content as is
                Detail_field_json = [log_message_Detail_field]
        else:
            # If the Detail field is not a dictionary, or h323 test details then just return the string as a list of string ()
            Detail_field_json = [log_message_Detail_field]
    else:
        # If the parser failed
        Detail_field_json = [log_message_Detail_field]
    return Detail_field_json


'''
------------------------------------------------------------------------------
 * Function which parses the Pexip Infinity servers support logs
------------------------------------------------------------------------------'''
def parse_pexip_support_logs_to_json(log, debugging_log_level):
    debug_header = 'parse_pexip_support_logs_to_json :: '
    # Prevent side effects on the original log object. Shallow copy is enough as at this stage the dictionary contains only strings as values
    support_log = log.copy()
    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
        logger.info(debug_header + 'Start parsing a new Support log')
        logger.info(debug_header + 'Extracting support logs basic fields')
    # Extract the timestamp in the UNiX format, such as yyyy-mm-dd hh:mm:ss[.f...]
    support_log['syslog_time'] = str.replace(re.match(r'^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}).*$',support_log['syslog_time']).group(1),'T',' ')
    # Extract the support log level information
    support_log['level'] = re.match(r'^Level=\"(.*)\"',support_log['level']).group(1)
    # Extract from the support log the name of the type of logs (i.e. support.sip, support.rest, support.ice, support.dns ...)
    support_log_name = re.match(r'^Name=\"(.*)\"',support_log['name']).group(1)
    support_log['name'] = support_log_name

    # Start parsing the log message itself. The logs are parsed differently based on the content of the 'name' field above.
    # Refer to 'Pexip Infinity Diqgnostic - Log Output' documentation
    # The log message start with the field "Message" followed by the content
    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
        logger.info(debug_header + 'Start parsing the support log\'s log message itself')
    log_message_content = re.match(r'^Message=\"([^\"]*)\" (.*)$',support_log['log_message'])

    # We need to initialize the structure of the log detail content depending on the chosen format
    log_message_json = {}

    if(log_message_content):
        # First add the Message type found in the details
        format_json_key_value_pair('support', log_message_json, 'Message', log_message_content.group(1))
        # Then each message has its own content. The rest of the content is first parsed using a regex
        # and then added to the json
        # Most support logs have a field called "Detail" which can have different format :
        #   1- a SIP message, which can contain the " character but ends with ^M" (that is captured by the first part of the regex)
        #      Detail="^MSIP/2.0 200 OK^MVia: SIP/2.0/TLS ... From: "from_name" ... ^M"
        #   2- Or it can be something else like Detail="{key1: value1, key2: value2}"
        log_message_content_iterator = re.finditer(r'Detail=\"(.*)\^M\"(?:\s|$)|(\S*)=\"([^\"]*)\"(?:$|\s)',log_message_content.group(2))
        for log_message_key_value in log_message_content_iterator:
            # Check if the key-value pair is not the first pattern (Detail=".....^M")
            # which means the "Detail" field inside the log message contains a SIP messages
            # with lines separated by ^M
            if log_message_key_value.group(1) or (log_message_key_value.group(2) and log_message_key_value.group(2) == 'Detail'):
                # Analyse the "Detail" field of the log message
                if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                    logger.info(debug_header + 'Parsing the "Detail" field content inside the support log message.')
                if log_message_key_value.group(1):
                    log_message_Detail_field_content = log_message_key_value.group(1)
                else:
                    log_message_Detail_field_content = log_message_key_value.group(3)
                message_Detail_json = parse_support_logs_Detail_field(support_log_name, log_message_Detail_field_content,  debugging_log_level)
                # The content of the "Detail" field of the message has been parsed. Add the JSON formated result to the message
                log_message_json['Detail'] = message_Detail_json
            else:
                # The key-value pair in the log message is not the "Detail" field 
                # Just add the key-value pair to the JSON dictionary
                format_json_key_value_pair('support', log_message_json, log_message_key_value.group(2), log_message_key_value.group(3))
    else:
        log_message_json['message'] = ''
    support_log['log_message'] = log_message_json
    return support_log


'''
------------------------------------------------------------------------------
 * Function which parses the Pexip Infinity servers audit logs
------------------------------------------------------------------------------'''
def parse_pexip_audit_logs_to_json(log, debugging_log_level):
    debug_header = 'parse_pexip_audit_logs_to_json :: '
    # Prevent side effects on the original log object. Shallow copy is enough as at this stage the dictionary contains only strings as values
    audit_log = log.copy()
    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
        logger.info(debug_header + 'Start parsing a new Audit log')
        logger.info(debug_header + 'Extracting the Audit logs basic fields')
    # Extract the timestamp in the UNiX format, such as yyyy-mm-dd hh:mm:ss[.f...]
    audit_log['syslog_time'] = str.replace(re.match(r'^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}).*$',audit_log['syslog_time']).group(1),'T',' ')
    # Extract the audit log type information
    audit_log['type'] = re.match(r'^type=(.*)$',audit_log['type']).group(1)
    # Extract from the audit log the Pexip Infinity server FQDN
    audit_log['system_fqdn'] = re.match(r'^node=(.*)',audit_log['system_fqdn']).group(1)

    # There can be 2 messages inside the audit log details. 
    # The main message in the format : msg=.*
    # or a sub message in the format : msg='.*'
    # The second one will be renamed "submsg" because we can't have two keys with the same name "msg"
    # Extract the first message from the audit log and add it to the parsed json log
    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
        logger.info(debug_header + 'Parsing the audit logs basic Message field')

    # Initialize the structure of the log message content
    log_message_json = {}
    log_message_content = re.match(r'^msg=(audit\(.*\):((?!\w+=).)*)',audit_log['log_message'])
    format_json_key_value_pair('audit', log_message_json, 'msg', log_message_content.group(1))

    # In the rest of the log message, extract fields like pid, uid, auid,... fields from the auidt log and add them to the parsed json log
    log_message_without_main_message = str.replace(audit_log['log_message'],log_message_content.group(0),'')
    log_message_iterator = re.finditer(r'msg=\'(.*)\'|(\w*)=(\S*)($|\s)',log_message_without_main_message)

    # If the regex matched
    if (log_message_iterator):
        # Parse through all key=value data found using the regex
        for log_message_key_value in log_message_iterator:
            if log_message_key_value.group(1):
                # There is a sub msg field inside the msg field
                # Extract the sub message inside the audit log details and start parsing it
                if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                    logger.info(debug_header + 'Parsing the audit logs basic Message\'s sub message')
                log_message_sub_msg = log_message_key_value.group(1)
                # Extract all elements of the sub message
                log_message_sub_msg_iterator = re.finditer(r'(\w*)=(\S*)($|\s)',log_message_sub_msg)
                # If we were able to extract fields in the sub message
                if (log_message_sub_msg_iterator):
                    # First initialise the JSON structure of the sub message
                    log_message_sub_msg_json = {}
                    # Then parse the content and format it
                    for log_message_sub_msg_match in log_message_sub_msg_iterator:
                        format_json_key_value_pair('audit', log_message_sub_msg_json, log_message_sub_msg_match.group(1), log_message_sub_msg_match.group(2),True)
                    # All the sub message content have been parsed
                    # add the parsed sub message as a nested json
                    log_message_json['submsg'] = log_message_sub_msg_json
                else:
                    # Couldn't parse the sub message so return it as is
                    format_json_key_value_pair('audit', log_message_json, 'submsg', log_message_sub_msg)
            elif log_message_key_value.group(2):
                # A key=value was extracted from the log message
                format_json_key_value_pair('audit', log_message_json, log_message_key_value.group(2), log_message_key_value.group(3),True)
    else:
        # The regex did not match the log message so return the content as one long string
        format_json_key_value_pair('audit', log_message_json, 'msg', log_message_without_main_message)
    # Add the parsed log message
    audit_log['log_message'] = log_message_json
    return audit_log


'''
------------------------------------------------------------------------------
 * Function which parses the Pexip Infinity servers Apache Web Server logs
------------------------------------------------------------------------------'''
def parse_pexip_apache_logs_to_json(log, debugging_log_level):
    debug_header = 'parse_pexip_apache_logs_to_json :: '
    # Prevent side effects on the original log object. Shallow copy is enough as at this stage the dictionary contains only strings as values
    apache_log = log.copy()
    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
        logger.info(debug_header + 'Start parsing a new Apache Web Server log')
        logger.info(debug_header + 'Extracting the Apache Web Server logs basic fields')
    # Extract the timestamp in the UNiX format, such as yyyy-mm-dd hh:mm:ss[.f...]
    apache_log['syslog_time'] = str.replace(re.match(r'^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}).*$',apache_log['syslog_time']).group(1),'T',' ')
    # Extract from the audit log the Pexip Infinity server FQDN
    apache_log['apache'] = apache_log['apache'].strip(':')

    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
        logger.info(debug_header + 'Parsing the Apache Web Server log message field')

    # Initialize the structure of the log message content
    log_message_json = {}
    try:
        log_message_content = re.match(r'([(\d\.)]+) (\S+) (\S+) \[(.*?):(.*?) (\+\d{4})\] \"(.*?)\" (\S+) (\d{3}) (\S+) (\S+) \"(.*?)\" \"(.*?)\"',apache_log['log_message'])
        if log_message_content:
            log_message_json['RemoteIPOrHost'] = log_message_content.group(1)
            log_message_json['RemoteLogname'] = log_message_content.group(2)
            log_message_json['RemoteUser'] = log_message_content.group(3)
            log_message_json['LogDate'] = log_message_content.group(4)
            log_message_json['LogTime'] = log_message_content.group(5)
            log_message_json['TimeZone'] = log_message_content.group(6)
            log_message_json['Request'] = log_message_content.group(7)
            log_message_json['pid'] = log_message_content.group(8)
            log_message_json['HTTPStatusCode'] = log_message_content.group(9)
            log_message_json['BytesReceived'] = log_message_content.group(10)
            log_message_json['BytesSent'] = log_message_content.group(11)
            log_message_json['URL'] = log_message_content.group(12)
            log_message_json['User_Agent'] = log_message_content.group(13)
            # Add the parsed log message
            apache_log['log_message'] = log_message_json
    except Exception as e:
        logger.info(debug_header + 'ERROR parsing the Web Server log message string. The log message won\'t be wrangled in JSON and will be kept as a string.')
        logging.info(debug_header + 'ERROR: ' + str(e))
    # If the log message was not parsed the key 'log_message' will keep it's value containing the log message as a string
    return apache_log


'''
------------------------------------------------------------------------------
 * Main Lambda Function handler
------------------------------------------------------------------------------'''
def lambda_handler(event, context):
    debug_header = 'lambda_handler :: '
    try:
        log_export_function_name = os.environ['LOG_EXPORT_FUNCTION']
        export_to_s3 = os.environ['EXPORT_TO_S3'] == 'True'
        export_to_cloudwatch_logs = os.environ['EXPORT_TO_CLOUDWATCH_LOGS'] == 'True'
        debugging_log_level = os.environ['DEBUGGING_LOG_LEVEL']
    except:
        logger.info(debug_header + 'FATAL ERROR. Lambda environment variable "LOG_EXPORT_FUNCTION", "EXPORT_TO_S3", "EXPORT_TO_CLOUDWATCH_LOGS" not set.')
        return 'failed'

    logger.info(debug_header + 'Start wrangling the Pexip logs into JSON.')

    if (debugging_log_level == 'Debug'):
        logger.info(json.dumps(event))
      
    # Capture the CloudWatch log data
    outEvent = str(event['awslogs']['data'])
    
    # Decode and unzip the log data
    outEvent = gzip.decompress(base64.b64decode(outEvent))
    
    # Convert the log data from JSON into a dictionary
    cleanEvent = json.loads(outEvent)
    log_group = cleanEvent['logGroup']
    log_stream = cleanEvent['logStream']
    log_events = cleanEvent['logEvents']
    log_content_json = []
    for log in log_events:
        if (debugging_log_level == 'Debug'):
            logger.info(debug_header + ' Log Content: ' + json.dumps(log))
        if 'Support' in log_group:
            log_type = 'support'
            json_log = parse_pexip_support_logs_to_json(log['extractedFields'], debugging_log_level)
        elif 'Audit' in log_group:
            log_type = 'audit'
            json_log = parse_pexip_audit_logs_to_json(log['extractedFields'], debugging_log_level)
        elif 'Web_Server' in log_group:
            log_type = 'apache'
            json_log = parse_pexip_apache_logs_to_json(log['extractedFields'], debugging_log_level)
        log_content_json.append(json_log)
    
    # Launch the Lambda function to write the logs to S3 and/or re-import them to CloudWatch
    lam = boto3.client('lambda')
    logger.info(debug_header + "Launching Lambda function " + log_export_function_name + " to export the logs")
    try:
        response = lam.invoke(FunctionName = log_export_function_name,
            InvocationType = 'Event',
            Payload=json.dumps({
                "log_group": log_group,
                "log_stream": log_stream,
                "log_type": log_type,
                "export_to_s3": export_to_s3,
                "export_to_cloudwatch_logs": export_to_cloudwatch_logs,
                "log_content_json": log_content_json
            })
        )
    except ClientError as e:
        # Catching AWS boto3 exceptions
        logger.info(debug_header + 'Raising exception while invoking the Lambda function: "' + log_export_function_name + '" to export the wrangled logs to S3 and/or CloudWatch Logs.')
        logging.info(debug_header + 'BOTO3 ERROR: ' + str(e))
    except Exception as e:
        # Catching other exceptions
        logger.info(debug_header + 'Raising exception while invoking the Lambda function: "' + log_export_function_name + '" to export the wrangled logs to S3 and/or CloudWatch Logs.')
        logging.info(debug_header + 'ERROR: ' + str(e))

    # Log wrangling end
    logger.info(debug_header + 'Finished wrangling the Pexip logs into JSON. Ending now...')
    return 'success'