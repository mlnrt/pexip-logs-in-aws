'''
/* This file is under the MIT License
 * 
 * Copyright (c) 2019 mlnrt
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
------------------------------------------------------------------------------


@author Matthieu Lienart
@date Mai 2019
'''
import logging
import os
import boto3
import json
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    debug_header = 'lambda_handler :: '

    s3 = boto3.client('s3')
    glue = boto3.client('glue')

    try:
        s3_bucket_name = os.environ['S3_BUCKET_NAME']
        pexip_audit_logs_s3_folder = os.environ['PEXIP_AUDIT_LOGS_S3_FOLDER']
        pexip_support_logs_s3_folder = os.environ['PEXIP_SUPPORT_LOGS_S3_FOLDER']
        pexip_logs_datadata_file = os.environ['PEXIP_LOGS_METADATA_FILE']
        process_audit_logs = os.environ['PROCESS_AUDIT_LOGS'] == 'True'
    except:
        logger.info(debug_header + 'FATAL ERROR. Lambda environment variable "S3_BUCKET_NAME", "PEXIP_AUDIT_LOGS_S3_FOLDER", "PEXIP_SUPPORT_LOGS_S3_FOLDER", "PEXIP_LOGS_METADATA_FILE" and "PROCESS_AUDIT_LOGS" not set.')
        return 'failed'

    # Set some default values if not passed in the environment varibles
    try:
        debugging_log_level = os.environ['DEBUGGING_LOG_LEVEL']
    except:
        debugging_log_level = 'Info'

    try:
        update_glue_table_if_already_exist = os.environ['UPDATE_GLUE_TABLE_IF_ALREADY_EXIST'] == 'True'
    except:
        debugging_log_level = False
        
    try:
        create_glue_tables_partitions_function_name = os.environ['CREATE_GLUE_TABLES_PARTITIONS_FUNCTION_NAME'] 
    except:
        create_glue_tables_partitions_function_name = 'Pexip_Logs_Create_Glue_Tables_Partitions'

    try:
        create_or_update_tables_partitions = os.environ['CREATE_OR_UPDATE_TABLES_PARTITIONS_AT_THE_SAME_TIME'] == 'True'
    except:
        create_or_update_tables_partitions = False


    logging.info(debug_header + 'Starting to create the Glue Tables')

    # Read the JSON data to create the tables
    try:
        json_file_content = s3.get_object(Bucket=s3_bucket_name,Key=pexip_logs_datadata_file)['Body'].read()
        #json_file_content = open(os.environ['LAMBDA_TASK_ROOT'] + '/' + pexip_logs_datadata_file).read()
        logs_metadata = json.loads(json_file_content)
        if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
            logging.info(debug_header + 'Read the logs metadata information from the JSON file ' + pexip_logs_datadata_file + '.')
        if (debugging_log_level == 'Debug'):
            logging.info(debug_header + 'Metadata read from the file: ' + json.dumps(logs_metadata))
    except:
        logger.info(debug_header + 'FATAL ERROR. Could not load the JSON file ' + pexip_logs_datadata_file + '.')
        return 'failed'

    if process_audit_logs:
        log_types = ['audit','support']
    else:
        log_types = ['support']

    try:
        # For both the Audit and Support types of logs
        for log_type in log_types:
            # Initialize variables for both types of logs
            if log_type == 'audit':
                s3_folder_name = pexip_audit_logs_s3_folder
            else:
                s3_folder_name = pexip_support_logs_s3_folder
            log_names = logs_metadata[log_type]['log_names']
            log_struct = logs_metadata[log_type]['log_struct']
            log_path = logs_metadata[log_type]['paths']
            glue_database_name = logs_metadata[log_type]['glue_database_name']
            log_columns = logs_metadata[log_type]['columns']
            
            for log_name in log_names:
                glue_table_name = str.replace(log_name,'.','_').lower()
                # Create the Glue Table
                log_s3_target = 's3://' + s3_bucket_name + '/' + s3_folder_name + '/' + log_name
                # Set the structure of the log_message column of the table
                for log_column in log_columns:
                    if log_column['Name'] == 'log_message':
                        log_column['Type'] = log_struct[log_name]
                # Check if the table already exists
                try:
                    table = glue.get_table(DatabaseName=glue_database_name, Name=glue_table_name)
                    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                        logger.info(debug_header + 'The table ' + glue_table_name + ' already exists in Glue.')
                    if update_glue_table_if_already_exist:
                        glue_response = glue.update_table(
                            DatabaseName=glue_database_name,
                            TableInput={
                                "Name": glue_table_name,
                                "Description": "Pexip " + log_type + " " + log_name + " logs",
                                "StorageDescriptor": {
                                    "Columns": log_columns,
                                    "Location": log_s3_target,
                                    "InputFormat": "org.apache.hadoop.mapred.TextInputFormat",
                                    "OutputFormat": "org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat",
                                    "SerdeInfo": {
                                        "SerializationLibrary": "org.openx.data.jsonserde.JsonSerDe",
                                        "Parameters": {
                                            "ignore.malformed.json": "True",
                                            "paths":log_path
                                        }
                                    }
                                },
                                "PartitionKeys": [
                                    {
                                        "Name": "year_partition",
                                        "Type": "string"
                                    },
                                    {
                                        "Name": "month_partition",
                                        "Type": "string"
                                    },
                                    {
                                        "Name": "day_partition",
                                        "Type": "string"
                                    }
                                ],
                                "TableType": "EXTERNAL_TABLE",
                                "Parameters": {
                                    "classification": "json",
                                    "typeOfData": "file"
                                }
                            }
                        )
                        if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                            logging.info(debug_header + 'Edited Pexip ' + log_type + 'logs Glue table: ' + log_s3_target)
                    else:
                        if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                            logger.info(debug_header + 'No changes made to the table: ' + glue_table_name)
                except:
                    # If there was an error it is because the table did not exist. Let's create it
                    glue_response = glue.create_table(
                        DatabaseName=glue_database_name,
                        TableInput={
                            "Name": glue_table_name.lower(),
                            "Description": "Pexip " + log_type + " " + log_name + " logs",
                            "StorageDescriptor": {
                                "Columns": log_columns,
                                "Location": log_s3_target,
                                "InputFormat": "org.apache.hadoop.mapred.TextInputFormat",
                                "OutputFormat": "org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat",
                                "SerdeInfo": {
                                    "SerializationLibrary": "org.openx.data.jsonserde.JsonSerDe",
                                    "Parameters": {
                                        "ignore.malformed.json": "True",
                                        "paths":log_path
                                    }
                                }
                            },
                            "PartitionKeys": [
                                {
                                    "Name": "year_partition",
                                    "Type": "string"
                                },
                                {
                                    "Name": "month_partition",
                                    "Type": "string"
                                },
                                {
                                    "Name": "day_partition",
                                    "Type": "string"
                                }
                            ],
                            "TableType": "EXTERNAL_TABLE",
                            "Parameters": {
                                "classification": "json",
                                "typeOfData": "file"
                            }
                        }
                    )
                    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                        logging.info(debug_header + 'Created Glue table ' + glue_table_name + ' for Pexip logs in ' + log_s3_target)
                
                # By now the table has either been created or updated.
                # Create/update the partitions if asked for it
                if create_or_update_tables_partitions:
                    lam = boto3.client('lambda')
                    try:
                        lam_response = lam.invoke(FunctionName = create_glue_tables_partitions_function_name,
                            InvocationType = 'Event',
                            Payload=json.dumps({
                                "log_type": log_type,
                                "log_name": log_name,
                                "date_to_crawl": "",
                                "s3_bucket_name": s3_bucket_name,
                                "pexip_audit_logs_s3_folder": pexip_audit_logs_s3_folder,
                                "pexip_support_logs_s3_folder": pexip_support_logs_s3_folder,
                                "pexip_logs_datadata_file": pexip_logs_datadata_file,
                                "update_existing_glue_tables_partitions": True
                            })
                        )
                        if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                            logging.info(debug_header + 'Launched the Lambda function Pexip_Logs_Create_Glue_Tables_Partitions to try to create and update the Partitiond for the Glue table: ' + glue_table_name)
                    except ClientError as e:
                        # Catching AWS boto3 exceptions
                        logging.info(debug_header + 'Raising exception while launching the Lambda Function "' + create_glue_tables_partitions_function_name + '" to create or update the Partitions for the Glue table: ' + log_name)
                        logging.info(debug_header + 'BOTO3 ERROR: ' + str(e))
                    except Exception as e:
                        # Catching other exceptions
                        logging.info(debug_header + 'Raising exception while launching the Lambda Function "' + create_glue_tables_partitions_function_name + '" to create or update the Partitions for the Glue table: ' + log_name)
                        logging.info(debug_header + 'ERROR: ' + str(e))
                else:
                    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                        logging.info(debug_header + 'No partitions were created or updated for the Glue table: ' + glue_table_name)

    except ClientError as e:
        # Catching AWS boto3 exceptions
        logging.info(debug_header + 'Raising exception while creating the Glue Tables.')
        logging.info(debug_header + 'BOTO3 ERROR: ' + str(e))
    except Exception as e:
        # Catching other exceptions
        logging.info(debug_header + 'Raising exception while creating the Glue Tables.')
        logging.info(debug_header + 'ERROR: ' + str(e))
    logging.info(debug_header + 'Finished creating or updating the Glue Tables')
    return 'success'
