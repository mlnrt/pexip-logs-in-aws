'''
/* This file is under the MIT License
 * 
 * Copyright (c) 2019 mlnrt
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
------------------------------------------------------------------------------

This function creates paritions for a single Glue table (passed in the event argument "log_name") containing the corresponding Pexip Infinity logs.
It creates partitions for only one Glue table (type of log) on purpose as comuptation time and resources are limited with serverless functions.
If you need to create partitions for all the Pexip logs stored in S3, launch the Lamba function "Pexip_Logs_Create_Glue_Tables"
with the environment parameter "CREATE_OR_UPDATE_TABLES_PARTITIONS_AT_THE_SAME_TIME" set to "True".
Each time that Lambda funtion finds an existing Glue table or creates a new one, it will asynchronously invoke one instance of this function to create the partitions for thaat particular table.
This will decouple the creation of partitions accross multiple executions of the "Pexip_Logs_Create_Glue_Tables_Partitions" Lambda function; one per Glue table (log type)

Events passed to this function should be in the JSON format. 
When "log_type" and "log_name" are left blank the function will abord to avoid running the function on all the possible logs.
When "date_to_crawl" is specified the function will crawl only objects with the key prefix /YYYY/MM/DD/ to create partitions.
    If blank, the function will crawl all the S3 objects to create partitions from all objects with keys in the format /YYYY/MM/DD/. 
{
    "log_type": "audit" or "support",
    "log_name": "name of the log type stored in S3 for which we want to create a partition. E.g. support.ice",
    "date_to_crawl": "YYYY-MM-DD",
    "s3_bucket_name": "bucket-name" (Optional. If not present, use the Function's environment parameter),
    "pexip_audit_logs_s3_folder": "folder-name" (Optional. If not present, use the Function's environment parameter),
    "pexip_support_logs_s3_folder": "folder-name" (Optional. If not present, use the Function's environment parameter),
    "pexip_logs_datadata_file": "file-name.json" (Optional. If not present, use the Function's environment parameter),
    "update_existing_glue_tables_partitions": "True" or "False" (Optional. If not present, use the Function's environment parameter)
}

@author Matthieu Lienart
@date Mai 2019
'''
import logging
import os
import boto3
import json
import re
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    debug_header = 'lambda_handler :: '

    s3 = boto3.client('s3')
    glue = boto3.client('glue')

    # Get the environment variables. The values for the environment variables received through the Event take precedence over the ones assigned to the function
    try:
        if 's3_bucket_name' in event:
            s3_bucket_name = event['s3_bucket_name']
        else:
            s3_bucket_name = os.environ['S3_BUCKET_NAME']
        if 'pexip_audit_logs_s3_folder' in event:
            pexip_audit_logs_s3_folder = event['pexip_audit_logs_s3_folder']
        else:
            pexip_audit_logs_s3_folder = os.environ['PEXIP_AUDIT_LOGS_S3_FOLDER']
        if 'pexip_support_logs_s3_folder' in event:
            pexip_support_logs_s3_folder = event['pexip_support_logs_s3_folder']
        else:
            pexip_support_logs_s3_folder = os.environ['PEXIP_SUPPORT_LOGS_S3_FOLDER']
        if 'pexip_logs_datadata_file' in event:
            pexip_logs_datadata_file = event['pexip_logs_datadata_file']
        else:
            pexip_logs_datadata_file = os.environ['PEXIP_LOGS_METADATA_FILE']
    except:
        logger.info(debug_header + 'FATAL ERROR. Lambda environment variable "S3_BUCKET_NAME", "PEXIP_AUDIT_LOGS_S3_FOLDER", "PEXIP_SUPPORT_LOGS_S3_FOLDER" and "PEXIP_LOGS_METADATA_FILE" not set.')
        return 'failed'

    # Set some default values if not passed in the environment parameters
    try:
        debugging_log_level = os.environ['DEBUGGING_LOG_LEVEL']
    except:
        debugging_log_level = 'Info'

    try:
        s3_list_max_keys = int(os.environ['MAX_NUMBER_OF_FILES_RETRIEVED_PER_S3_QUERY'])
    except:
        s3_list_max_keys = 10000

    try:
        if 'update_existing_glue_tables_partitions' in event:
            update_existing_glue_tables_partitions = event['update_existing_glue_tables_partitions']
        else:
            update_existing_glue_tables_partitions = os.environ['UPDATE_EXISTING_GLUE_TABLES_PARTITIONS'] == 'True'
    except:
        update_existing_glue_tables_partitions = False

    if (debugging_log_level == 'Debug'):
        logger.info(debug_header + 'Received data' + json.dumps(event))


    try:
        if not event['log_name'] == '':
            log_name = event['log_name']
        else:
            logger.info(debug_header + 'FATAL ERROR. The "log_name" key inside the JSON event passed to the function can\'t be blank.')
            return 'failed'
        log_type = event['log_type']
        if log_type != 'audit' and log_type != 'support':
            logger.info(debug_header + 'FATAL ERROR. The "log_type" key inside the JSON event passed to the function must be either "audit" or "support".')
            return 'failed'
        date_to_crawl = event['date_to_crawl']
        parsed_date = re.match(r'^(\d{4})-(\d\d?)-(\d\d?)$',date_to_crawl)
        if parsed_date:
            log_year = parsed_date.group(1)
            log_month = parsed_date.group(2)
            log_day = parsed_date.group(3)
            date_to_crawl_s3_key = str.replace(date_to_crawl,'-','/')
        else:
            date_to_crawl_s3_key = None
            logger.info(debug_header + 'No "date_to_crawl" specified, or not in the format YYYY-MM-DD. The function will crawl all dates and create partitions.')
        glue_table_name = str.replace(log_name,'.','_').lower()
    except:
        logger.info(debug_header + 'FATAL ERROR. There was an issue retrieving the values from the keys: "log_type" and "log_name" in the JSON event passed to the function. "log_type" must be either "audit" or "support". Also, specify the "log_name" for which you want this function to create a partition.')
        return 'failed'

    # Read the JSON data to create the tables
    try:
        json_file_content = s3.get_object(Bucket=s3_bucket_name,Key=pexip_logs_datadata_file)['Body'].read()
        #json_file_content = open(os.environ['LAMBDA_TASK_ROOT'] + '/' + pexip_logs_datadata_file).read()
        logs_metadata = json.loads(json_file_content)
        if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
            logging.info(debug_header + 'Read the logs metadata information from the JSON file ' + pexip_logs_datadata_file + '.')
        if (debugging_log_level == 'Debug'):
            logging.info(debug_header + 'Metadata read from the file: ' + json.dumps(logs_metadata))
    except:
        logger.info(debug_header + 'FATAL ERROR. Could not load the JSON file ' + pexip_logs_datadata_file + '.')
        return 'failed'


    logging.info(debug_header + 'Starting to create or to update the Partitions for the Glue Table: ' + glue_table_name)

    try:
        # Initialize variables for both types of logs
        if log_type == 'audit':
            s3_folder_name = pexip_audit_logs_s3_folder
        else:
            s3_folder_name = pexip_support_logs_s3_folder
        glue_database_name = logs_metadata[log_type]['glue_database_name']
        log_struct = logs_metadata[log_type]['log_struct']
        log_columns = logs_metadata[log_type]['columns'].copy()
        for log_column in log_columns:
            if log_column['Name'] == 'log_message':
                log_column['Type'] = log_struct[log_name]
        log_path = logs_metadata[log_type]['paths']

        if date_to_crawl_s3_key:
            # Crawl the logs at a specific date
            log_s3_target_path = s3_folder_name + '/' + log_name + '/' + date_to_crawl_s3_key
        else:
            # Crawl the logs at all dates
            log_s3_target_path = s3_folder_name + '/' + log_name
        log_s3_target = 's3://' + s3_bucket_name + '/' + log_s3_target_path

        # Get all the objects in the S3 bucket for the log type and date specified
        s3_response = s3.list_objects_v2(
            Bucket= s3_bucket_name,
            Prefix= log_s3_target_path,
            MaxKeys=s3_list_max_keys
        )
        if (debugging_log_level == 'Debug'):
            logging.info(debug_header + 'Result of the search for log objects inside ' + log_s3_target + ' : ' + str(s3_response))
        # Was there any log found?
        if len(s3_response['Contents']) > 0:
            s3_log_objects = s3_response['Contents']
            # If a specific date for which to create a partition was passed as an argument
            if date_to_crawl_s3_key:
                # Check if the partition exist already
                try:
                    glue_partition = glue.get_partition(
                        DatabaseName= glue_database_name,
                        TableName= glue_table_name,
                        PartitionValues=[log_year,log_month,log_day]
                    )
                    # If it doesn't fail it means the partition already exists 
                    # Update it if asked for it
                    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                        logging.info(debug_header + 'The partition already exists for the date "' + date_to_crawl_s3_key + '" for the Glue table "' + glue_table_name + '".')
                    if update_existing_glue_tables_partitions:
                        glue.update_partition(
                            DatabaseName= glue_database_name,
                            TableName= glue_table_name,
                            PartitionValueList= [log_year,log_month,log_day],
                            PartitionInput={
                                "Values": [log_year,log_month,log_day],
                                "StorageDescriptor": {
                                    "Columns": log_columns,
                                    "Location": log_s3_target,
                                    "InputFormat": "org.apache.hadoop.mapred.TextInputFormat",
                                    "OutputFormat": "org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat",
                                    "SerdeInfo": {
                                        "SerializationLibrary": "org.openx.data.jsonserde.JsonSerDe",
                                        "Parameters": {
                                            "ignore.malformed.json": "True",
                                            "paths":log_path
                                        }
                                    }
                                }
                            }
                        )
                        if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                            logging.info(debug_header + 'The partition for the date ' + date_to_crawl_s3_key + ' was updated.')
                    else:
                        if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                            logging.info(debug_header + 'The partition for the date ' + date_to_crawl_s3_key + ' was not updated.')
                except:
                    # The get_partition failed. It means the partition does not exist.
                    # Go ahead and create the partition
                    glue.create_partition(
                        DatabaseName= glue_database_name,
                        TableName= glue_table_name,
                        PartitionInput={
                            "Values": [log_year,log_month,log_day],
                            "StorageDescriptor": {
                                "Columns": log_columns,
                                "Location": log_s3_target,
                                "InputFormat": "org.apache.hadoop.mapred.TextInputFormat",
                                "OutputFormat": "org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat",
                                "SerdeInfo": {
                                    "SerializationLibrary": "org.openx.data.jsonserde.JsonSerDe",
                                    "Parameters": {
                                        "ignore.malformed.json": "True",
                                        "paths":log_path
                                    }
                                }
                            }
                        }
                    )
                    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                        logging.info(debug_header + 'Created a new partition for the date ' + a_date + '" for the Glue table "' + glue_table_name + '".')
            else:
                # Create Partitions for all dates for which logs have been recorded into S3
                # First retrieve all the dates from the folders
                list_of_log_dates = []
                for a_log_file in s3_log_objects:
                    parsed_log_date = re.match(r'^'+re.escape(log_s3_target_path)+r'/(\d{4}/\d\d?/\d\d?).*',a_log_file['Key'])
                    if parsed_log_date:
                        log_date = parsed_log_date.group(1)
                        # Create a list of the dates for which logs are stored in s3
                        if log_date not in list_of_log_dates:
                            list_of_log_dates.append(log_date)
                # Check if the list of dates is not empty 
                if not list_of_log_dates == []:
                    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                        logging.info(debug_header + 'List of all the dates for which to create Partitions for the log table ' + glue_table_name + ' : ' + str(list_of_log_dates))
                    # Create a partition for all the dates for which partitions do not exist already
                    for a_date in list_of_log_dates:
                        parsed_date = re.match(r'^(\d{4})/(\d\d?)/(\d\d?)$',a_date)
                        if parsed_date:
                            log_year = parsed_date.group(1)
                            log_month = parsed_date.group(2)
                            log_day = parsed_date.group(3)
                        log_s3_target = 's3://' + s3_bucket_name + '/' + log_s3_target_path + '/' + a_date
                        # Check if the partition exist already
                        try:
                            glue_partition = glue.get_partition(
                                DatabaseName= glue_database_name,
                                TableName= glue_table_name,
                                PartitionValues=[log_year,log_month,log_day]
                            )
                            # If it doesn't fail it means the partition already exists 
                            # Update it if asked for it
                            if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                                logging.info(debug_header + 'The partition already exists for the date "' + a_date + '" for the Glue table "' + glue_table_name + '".')
                            if update_existing_glue_tables_partitions:
                                glue.update_partition(
                                    DatabaseName= glue_database_name,
                                    TableName= glue_table_name,
                                    PartitionValueList= [log_year,log_month,log_day],
                                    PartitionInput={
                                        "Values": [log_year,log_month,log_day],
                                        "StorageDescriptor": {
                                            "Columns": log_columns,
                                            "Location": log_s3_target,
                                            "InputFormat": "org.apache.hadoop.mapred.TextInputFormat",
                                            "OutputFormat": "org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat",
                                            "SerdeInfo": {
                                                "SerializationLibrary": "org.openx.data.jsonserde.JsonSerDe",
                                                "Parameters": {
                                                    "ignore.malformed.json": "True",
                                                    "paths":log_path
                                                }
                                            }
                                        }
                                    }
                                )
                                if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                                    logging.info(debug_header + 'The partition for the date ' + a_date + ' was updated.')
                            else:
                                if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                                    logging.info(debug_header + 'The partition for the date ' + a_date + ' was not updated.')
                        except:
                            # The get_partition failed. It means the partition does not exist.
                            # Go ahead and create the partition
                            glue.create_partition(
                                DatabaseName= glue_database_name,
                                TableName= glue_table_name,
                                PartitionInput={
                                    "Values": [log_year,log_month,log_day],
                                    "StorageDescriptor": {
                                        "Columns": log_columns,
                                        "Location": log_s3_target,
                                        "InputFormat": "org.apache.hadoop.mapred.TextInputFormat",
                                        "OutputFormat": "org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat",
                                        "SerdeInfo": {
                                            "SerializationLibrary": "org.openx.data.jsonserde.JsonSerDe",
                                            "Parameters": {
                                                "ignore.malformed.json": "True",
                                                "paths":log_path
                                            }
                                        }
                                    }
                                }
                            )
                            if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                                logging.info(debug_header + 'Created a new partition for the date ' + a_date + '" for the Glue table "' + glue_table_name + '".')
                else:
                    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                        logging.info(debug_header + 'Could not parse any date in the format /YYYY/MM/DD in any of the s3 objects inside ' + log_s3_target)
        else: 
            logging.info(debug_header + '-- No log objects found in the S3 bucket ' + s3_bucket_name + '/' + log_s3_target_path)

    except ClientError as e:
        # Catching AWS boto3 exceptions
        logging.info(debug_header + 'Raising Exception while  creating the partitions for the GLue Table: ' + glue_table_name)
        logging.info(debug_header + 'BOTO3 ERROR: ' + str(e))
    except Exception as e:
        # Catching other exceptions
        logging.info(debug_header + 'Raising Exception while  creating the partitions for the GLue Table: ' + glue_table_name)
        logging.info(debug_header + 'ERROR: ' + str(e))
    logging.info(debug_header + 'Finished creating or updating the Partitions for the Glue Table: ' + glue_table_name)
    return 'success'
