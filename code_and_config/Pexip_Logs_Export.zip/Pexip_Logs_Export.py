'''
/* This file is under the MIT License
 * 
 * Copyright (c) 2019 mlnrt
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
------------------------------------------------------------------------------

This function is invoked by the Lambda function "Pexip_Logs_Wrangling"
which passes through the handler's event the Pexip logs which it
has formatted in JSON.
It will export the logs to a different CloudWatch Logs log group
and an S3 bucket if configured to do so through the environment variables.

The code of this function is based on the code written by 
  @ V.Megler 
  @ Copyright 2017 Amazon.com 
  @ date August 2017  
provided in this blog post: https://aws.amazon.com/blogs/mt/how-to-export-ec2-instance-execution-logs-to-an-s3-bucket-using-cloudwatch-logs-lambda-and-cloudformation/

@author Matthieu Lienart
@date March 2019
'''
import boto3
import logging
import json
import time
import os
import random
import string
from datetime import datetime, timedelta
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)


'''
------------------------------------------------------------------------------
 * Function to generate a random string of letters and igits
------------------------------------------------------------------------------'''
def random_string_digits(string_length=20):
    letters_and_digits = string.ascii_letters + string.digits
    return ''.join(random.choice(letters_and_digits) for _ in range(string_length))


'''
------------------------------------------------------------------------------
 * Function which classifies the json logs by the log type
 *
 * For example:
 * {
 *    "ice": "text where each line is an ICE log message",
 *    "support.rest.sending": "text where each line is a sent REST support log message",
 *    "support.rest.received": "text where each line is a received REST support log message",
 * }
 *
 * For some log types, like SIP and REST messages, because 
 * the 'Detail' section of the log message has a different structure 
 * for sending and received messages, those logs are splitted
 * in two sub categories '.received' and '.sending' 
------------------------------------------------------------------------------'''
def classify_json_logs(json_log, log_type, debugging_log_level):
    debug_header = 'classify_json_logs :: '
    if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
        logger.info(debug_header + 'Start classifying the json formated logs by log type')
    if (debugging_log_level == 'Debug'):
        logger.info(debug_header + 'Logs to be classified: ' + json.dumps(json_log))

    log_names_to_split = ['support.sip', 'support.rest']
    
    classified_json_logs = {}
    # Retrieve the log class based on the type (audit ou support) log it is
    if (log_type == 'audit'):
        # For all logs in the data
        for log in json_log:
            log_class = log['type']
            # Check if we already have a section for this type of log
            # classified_json_logs[log_class] = (lambda log_class: classified_json_logs[log_class] + str(json.dumps(log)) + '\n' if log_class in classified_json_logs else json.dumps(log) + '\n')(log_class) 
            if (log_class in classified_json_logs):
                # If yes just append the log to the section's list
                classified_json_logs[log_class] = classified_json_logs[log_class] + str(json.dumps(log)) + '\n'
            else:
                # If not create the section's list and add the log in it
                classified_json_logs[log_class] = json.dumps(log) + '\n'
    elif (log_type == 'support'):
        # For all logs in the data
        for log in json_log:
            log_class = log['name']
            # For communication logs, we need to further split down between send and received messages as the format will be different
            if log_class in log_names_to_split:
                if 'Received' in log['log_message']['Message']:
                    log_class = log_class + '.received'
                elif 'Sending' in log['log_message']['Message']:
                    log_class = log_class + '.sending'
                else:
                    log_class = log_class + '.other'
            # Check if we already have a section for this type of log
            if (log_class in classified_json_logs):
                # If yes just append the log to the section's list
                classified_json_logs[log_class] = classified_json_logs[log_class] + str(json.dumps(log)) + '\n'
            else:
                # If not create the section's list and add the log in it
                classified_json_logs.update({log_class: json.dumps(log) + '\n'})

    if (debugging_log_level == 'Debug'):
        logger.info(debug_header + 'Log classification result: ' + json.dumps(classified_json_logs))
    return classified_json_logs


'''
------------------------------------------------------------------------------
 * Function which writes the json into various S3 object
------------------------------------------------------------------------------'''
def write_logs_to_s3(s3_bucket_name, s3_storage_class, log_group, log_stream, log_content_json, log_type, debugging_log_level):
    debug_header = 'write_logs_to_s3 :: '
    file_date_time = datetime.now()
    tstamp = '{0:.0f}'.format(((file_date_time - datetime(1970, 1, 1)).total_seconds())*100)

    classified_json_log = classify_json_logs(log_content_json, log_type, debugging_log_level)
    date_partition = '{}/{}/{}'.format(file_date_time.year, file_date_time.month, file_date_time.day) 

    # For each log type
    for log_class_key, log_class_content  in classified_json_log.items():
        # Add the log type in the S3 object path
        the_S3_key = '{}/{}/{}/{}_{}_{}.json'.format(log_group, log_class_key, date_partition, log_stream, log_class_key, tstamp)
        # Write the logs to S3
        if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
            logger.info(debug_header + 'Writing logs into the S3 bucket: "' + s3_bucket_name + '/' + log_class_key + '"')
        try:
            s3 = boto3.client('s3')
            response = s3.put_object(
                ACL='bucket-owner-full-control',
                Body=str(log_class_content),
                Bucket=s3_bucket_name,
                Key=the_S3_key,
                ServerSideEncryption='AES256',
                StorageClass=s3_storage_class
                )
        except ClientError as e:
            # Catching AWS boto3 exceptions
            logger.info(debug_header + 'Writing of s3://' + s3_bucket_name + '/' + the_S3_key + ' failed. Raising exception.')
            logging.info(debug_header + 'BOTO3 ERROR: ' + str(e))
        except Exception as e:
            # Catching other exceptions
            logger.info(debug_header + 'Writing of s3://' + s3_bucket_name + '/' + the_S3_key + ' failed. Raising exception.')
            logger.info(debug_header + 'ERROR: ' + str(e))


'''
------------------------------------------------------------------------------
 * Function which writes the json formatted logs into CloudWatchLogs
------------------------------------------------------------------------------'''
def write_to_cloudwatchlogs(log_group, stream_name, log_content_json, debugging_log_level):
    debug_header = 'write_to_cloudwatchlogs :: '
    logger.info(debug_header + 'Writing the logs back to CloudWatch in JSON format to: "' + log_group + '/' + stream_name + '"')

    cwlogs = boto3.client('logs')
    log_events = []
    for a_log in log_content_json:
        log_events.append({
                        'timestamp': int(datetime.strptime(a_log['syslog_time'], '%Y-%m-%d %H:%M:%S.%f').timestamp()*1000),
                        'message': json.dumps(a_log,indent=2)
                    })

    try:
        # Retrieve the log group
        log_groups = cwlogs.describe_log_groups(logGroupNamePrefix=log_group)['logGroups']
        # If the log group exists
        if (log_groups):
            # Just create the unique log stream
            if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                logger.info(debug_header + 'Creaating the log stream "' + log_group + '/' + stream_name + '"')
            cwlogs.create_log_stream(logGroupName=log_group, logStreamName=stream_name)
        else:
            # Create the log group and log stream first
            if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
                logger.info(debug_header + 'The log group logGroupName="' + log_group + '" does not exists.')
                logger.info(debug_header + 'Creating both the log group "' + log_group + '" and the log stream "' + stream_name + '"')
            cwlogs.create_log_group(logGroupName=log_group)
            cwlogs.create_log_stream(logGroupName=log_group, logStreamName=stream_name)

        # As this is a new stream we do not need any token

        response = cwlogs.put_log_events(
            logGroupName=log_group,
            logStreamName=stream_name,
            logEvents=log_events
            )

        if (debugging_log_level == 'Detailed') or (debugging_log_level == 'Debug'):
            logger.info(debug_header + 'The logs have been written back into CloudWatch Logs as JSON')
    except ClientError as e:
        # Catching AWS boto3 exceptions
        logger.info(debug_header + 'Raising exception while writing of CloudWatch log failed.')
        logging.info(debug_header + 'BOTO3 ERROR: ' + str(e))
    except Exception as e:
        # Catching other exceptions
        logger.info(debug_header + 'Raising exception while writing of CloudWatch log failed.')
        logger.info(debug_header + 'ERROR: ' + str(e))
    return 'success'


'''
------------------------------------------------------------------------------
 * Main Lambda Function handler
------------------------------------------------------------------------------'''
def lambda_handler(event, context):
    debug_header = 'lambda_handler :: '
    try:
        s3_bucket_name = os.environ['S3_BUCKET_NAME']
        s3_storage_class = os.environ['S3_STORAGE_CLASS']
        cloudwatchlogs_log_group_suffix = os.environ['CLOUDWATCHLOGS_LOG_GROUP_SUFFIX']
        debugging_log_level = os.environ['DEBUGGING_LOG_LEVEL']
    except:
        logger.info(debug_header + 'FATAL ERROR. Lambda environment variable "S3_BUCKET_NAME", "S3_STORAGE_CLASS", DEBUGGING_LOG_LEVEL" and "CLOUDWATCHLOGS_LOG_GROUP_SUFFIX" not set.')
        return 'failed'
    
    if (debugging_log_level == 'Debug'):
        logger.info(debug_header + json.dumps(event))

    # Extract the data from the event passed to the Lambda function
    log_group = event['log_group']
    log_stream = event['log_stream']
    log_type = event['log_type']
    export_to_s3 = event['export_to_s3']
    export_to_cloudwatch_logs = event['export_to_cloudwatch_logs']
    log_content_json = event['log_content_json']

    logger.info(debug_header + 'Start exporting the Pexip logs to S3/CloudWatch logs.')
    
    #Write the logs to S3
    if (export_to_s3):
        logger.info(debug_header + "Writing Pexip logs to S3")
        write_logs_to_s3(s3_bucket_name, s3_storage_class, str.replace(log_group,'_RAW',''), log_stream, log_content_json, log_type, debugging_log_level)

    # Write it out back again to CloudWatch in JSON format to use CloudWatch Logs Insight
    if (export_to_cloudwatch_logs):
        logger.info(debug_header + "Writing Pexip logs to CloudWatch")
        log_group_for_json = str.replace(log_group,'_RAW',cloudwatchlogs_log_group_suffix)
        # To avoid concurrent write issues to the same log stream - which will create issue
        # Make a unique log stream name per function execution
        # Add the date of the first log to the stream name to have one stream per date
        log_stream_for_json = log_content_json[0]['syslog_time'][0:10] + '_' + log_stream + '_' + random_string_digits()
        write_to_cloudwatchlogs(log_group_for_json, log_stream_for_json, log_content_json, debugging_log_level)

    # Log ending
    logger.info(debug_header + 'Finished exporting the Pexip logs to S3/CloudWatch logs. Ending now...')
    return 'success'
